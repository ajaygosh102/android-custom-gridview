package com.example.alexanderi.gridviewproject.GridViewCustom;

import android.content.res.TypedArray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.example.alexanderi.gridviewproject.R;

public class MainActivity extends AppCompatActivity {

    //Typed array holding all the images for the main categories
    TypedArray categoriesImages;
    //String array holding all the images for the main categories
    String[] categories;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categoriesImages = getResources().obtainTypedArray(R.array.categoriesImages);
        //categories = getResources().getStringArray(R.array.categories);


        ImageAdapter adapter = new ImageAdapter(MainActivity.this, /*categories*/null, categoriesImages);
        GridView grid = findViewById(R.id.grid_view);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Todo click on item in grid view
                Toast.makeText(MainActivity.this, position + " was clicked", Toast.LENGTH_SHORT).show();

            }//on item click
        });

    }//on create

}//main activity
