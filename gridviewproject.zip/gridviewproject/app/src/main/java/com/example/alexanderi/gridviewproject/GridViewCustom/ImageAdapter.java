package com.example.alexanderi.gridviewproject.GridViewCustom;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alexanderi.gridviewproject.R;

public class ImageAdapter extends BaseAdapter {
    //private variables
    private Context _context;
    private final TypedArray Imageid;
    private final String[] web;


    public ImageAdapter(Context c,String[] _web, TypedArray _Imageid ) {
        _context = c;
        this.Imageid = _Imageid;
        this.web = _web;

        Log.d("aaa", "onCreate: image id "+_Imageid);
        Log.d("aaa", "onCreate: web "+_web);

    }

    @Override
    public int getCount() {
        Log.d("aaa", "onCreate: count "+Imageid.length());

        return Imageid.length();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;

        if (convertView == null) {
            gridView = new View(_context);
            // get layout from mobile.xml
            gridView = inflater.inflate(R.layout.grid_layout, null);
            // set value into textview
            //TextView textView = gridView.findViewById(R.id.grid_item_label);
            //textView.setText(web[position]);
            // set image based on selected text
            ImageView imageView = gridView.findViewById(R.id.grid_item_image);
            imageView.setImageResource(Imageid.getResourceId(position, -1));
        }//if
        else {
            gridView = (View) convertView;
        }//else

        return gridView;
    }//getview

}//image adapter